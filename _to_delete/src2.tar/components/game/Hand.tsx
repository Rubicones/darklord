"use client";

import { isHint } from "@/lib/cards";
import { getPlayer, hintsIn, MAX_HINTS_PER_TURN } from "@/lib/game/engine";
import { Avatar, CardImg, LookPips } from "./bits";
import { useGame } from "./context";

export function Hand() {
  const { state, viewerId, openPlay, canActFor, controlAll } = useGame();
  const p = getPlayer(state, viewerId);
  if (!p) {
    return (
      <div className="px-4 pb-4 text-center text-sm text-parch/50">
        {controlAll ? "Нажмите на слугу сверху, чтобы открыть его руку" : "Вы наблюдаете за столом"}
      </div>
    );
  }
  const hand = [...p.hand].sort((a, b) => Number(isHint(b)) - Number(isHint(a)));
  const interactive = canActFor(p.id) && !p.out;
  const speaking = state.speakerId === p.id;
  const overLimit = speaking && state.hintsThisTurn >= MAX_HINTS_PER_TURN;
  const noHints = hintsIn(p).length === 0;
  const firstAction = hand.findIndex((c) => !isHint(c));

  return (
    <section className="relative">
      <div className="flex items-center gap-2 px-4 pb-1">
        <Avatar player={p} size={22} ring={speaking} />
        <span className="text-sm font-bold">{controlAll ? `Рука: ${p.name}` : "Ваша рука"}</span>
        <LookPips looks={p.looks} size={12} />
        <span className="ml-auto text-xs text-parch/50">
          намёков {hintsIn(p).length} · действий {p.hand.length - hintsIn(p).length}
        </span>
      </div>
      {(overLimit || (noHints && !p.out)) && (
        <p className="mx-4 mb-1 rounded-xl bg-blood/20 px-3 py-1.5 text-xs text-[#ffc2b5]">
          {overLimit
            ? "Сыграно 3 намёка — пора переводить стрелки, пока Владыка не разгневался!"
            : "Нет ни одного намёка… Владыка вправе испепелить взглядом."}
        </p>
      )}
      <div className="no-scrollbar flex items-end overflow-x-auto px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 sm:justify-center">
        {hand.length === 0 && <p className="w-full py-6 text-center text-sm text-parch/40">Рука пуста</p>}
        {hand.map((id, i) => (
          <button
            key={id}
            disabled={!interactive}
            onClick={() => openPlay({ actor: p.id, card: id })}
            style={{ zIndex: i, marginLeft: i > 0 && i === firstAction ? "0.75rem" : undefined }}
            className={`focus-ring group relative -ml-7 w-[6.6rem] shrink-0 rounded-[0.6rem] transition duration-200 first:ml-0 sm:-ml-3 sm:w-[7.6rem] lg:w-[8.4rem] ${
              interactive ? "hover:-translate-y-3 hover:rotate-[-1.5deg] active:-translate-y-2" : "cursor-default"
            }`}
          >
            <CardImg id={id} small className="card-shadow w-full animate-card-in" />
          </button>
        ))}
      </div>
    </section>
  );
}
