export type ActionKind = "pass" | "stop" | "both";
export type CardType = "hint" | "action" | "look";

export type CardDef = {
  id: string;
  type: CardType;
  title: string;
  action?: ActionKind;
  skull?: boolean;
};

const HINT_TITLES = [
  "Таверна",
  "Круглый щит",
  "Гвозди",
  "Экзотическая красавица",
  "Лестница",
  "Летающий город",
  "Разрушенный храм",
  "Сон-трава",
  "Колодец",
  "Череп",
  "Падал снег",
  "Таинственное зелье",
  "Ветер",
  "Болото",
  "Храбрый воин",
  "Тихая река",
  "Тёмный лес",
  "Восточный колдун",
  "Слизь",
  "Разумный меч",
  "Хрустальный шар",
  "Крохотный страж",
  "Королева-мумия",
  "Старый хищник",
  "Золото!",
  "Дверь",
  "Талисман",
  "Назойливое",
  "Каменный гигант",
  "Злобные суккубы",
  "Плащ чародея",
  "Рогатый шлем",
  "Молния",
  "Солнце",
  "Древнее дерево",
  "Тяжёлые цепи",
  "Одинокая башня",
  "Воющая книга",
  "Цветной жезл",
  "Факел",
  "Ключ",
  "Дракон",
  "Пугало",
  "Не то место",
  "Мерзкий прислужник",
  "Дама в беде",
  "Чёрный рыцарь",
  "Пиво дварфов",
  "Зомби!",
  "Запертый сундук",
  "Жадный монстр",
  "Неприступная стена",
  "Шахта",
  "Невообразимый артефакт",
  "Счастливая деревня",
  "Затерянный остров",
  "Свирепая эльфийка",
  "Другой Тёмный Властелин",
  "Тёмное поместье",
  "Окно в мир",
  "Древний дворец",
  "Мумия",
  "Растворимый меч",
  "Оглушительные штуки",
  "Непонятные письмена",
  "Страшный призрак",
  "Тысяча щупалец",
  "Карта",
  "Самый монструозный монстр",
  "Голая пустыня",
  "Мост через реку",
  "Пушечное мясо",
  "Модные ботинки",
  "Прожжённый делец",
  "Тёмное подземелье",
  "Летучий корабль",
  "Тупой гоблин",
  "Дорога",
  "Маленькая зверушка",
  "Море",
];

const pad = (n: number) => String(n).padStart(2, "0");
const range = (a: number, b: number) =>
  Array.from({ length: b - a + 1 }, (_, i) => a + i);

const BOTH = new Set([...range(1, 9), ...range(21, 24), 28]);
const STOP = new Set([...range(10, 18), ...range(25, 27)]);
const SKULL = new Set([...range(1, 7), ...range(12, 18), ...range(29, 37)]);

export const ACTION_LABEL: Record<"pass" | "stop", string> = {
  pass: "Перевод стрелок",
  stop: "Постой, паровоз!",
};

export const CARDS: Record<string, CardDef> = {};

export const HINT_IDS = HINT_TITLES.map((title, i) => {
  const id = `h${pad(i + 1)}`;
  CARDS[id] = { id, type: "hint", title };
  return id;
});

export const ACTION_IDS = range(1, 37).map((n) => {
  const id = `a${pad(n)}`;
  const action: ActionKind = BOTH.has(n) ? "both" : STOP.has(n) ? "stop" : "pass";
  const title =
    action === "both"
      ? "Стрелки или паровоз"
      : action === "stop"
        ? ACTION_LABEL.stop
        : ACTION_LABEL.pass;
  CARDS[id] = { id, type: "action", title, action, skull: SKULL.has(n) };
  return id;
});

export const LOOK_IDS = ["look1", "look2", "look3"];
LOOK_IDS.forEach((id, i) => {
  CARDS[id] = { id, type: "look", title: `Испепеляющий Взор ${"I".repeat(i + 1)}` };
});

export const canPass = (id: string) => {
  const a = CARDS[id]?.action;
  return a === "pass" || a === "both";
};
export const canStop = (id: string) => {
  const a = CARDS[id]?.action;
  return a === "stop" || a === "both";
};
export const isHint = (id: string) => CARDS[id]?.type === "hint";
export const isAction = (id: string) => CARDS[id]?.type === "action";

export const cardSrc = (id: string, small = false) =>
  `/cards/${id}${small ? "-s" : ""}.webp`;

export const BACK_HINT = "back-dark";
export const BACK_ACTION = "back-light";
